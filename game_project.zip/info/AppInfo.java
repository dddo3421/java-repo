package game_project.info;

import game_project.start.AppStart;

public class AppInfo extends AppStart{

	public void appinfo() { // 해당 애플리케이션에 대한 정보를 출력하고 메뉴로 돌아감 
		

		System.out.println("*********************************");
		System.out.println("         애플리케이션 정보            ");
		System.out.println("---------------------------------");
		System.out.println("제목 : 💜💜게임");
		System.out.println("제작자 : LJS");
		System.out.println("게임 목록 : 가위바위보 게임 / 숫자 알아맞히기 게임");
		System.out.println("기타 항목: 회원가입, 회원목록, 로그인, 회원정보 수정, 회원 탈퇴, 종료");
		System.out.println("*********************************");
		
		
	}	
		
	
}
